import tweepy

consumer_key="moA5lC8ePr2jaVNSjtVANaxdM"
consumer_secret="U9vGwuxK7ohStSUjksGlE3G7JbhslrEhtD9Jby1inpvxU6z62p"
access_token_key="923007546767572993-Tw3kbiIraEFUtCSmWXPR8vLQqFoiC2A"
access_token_secret="l3iYPVciQjLfvtzqTApWWeLRmxwJv0khqXme4XOhlXoHN"

auth = tweepy.OAuthHandler(consumer_key,consumer_secret)
auth.set_access_token(access_token_key,access_token_secret)

api=tweepy.API(auth)
user = [api.get_user(34373370,), api.get_user(26257166), api.get_user(12579252)]

i=0
while i<len(user):
    print 'The Friends List for:' 
    print 'User ID: ', user[i].id
    print 'user name :',user[i].name
    print 'screen name :',user[i].screen_name
    print''
    ct=0
    for friend in user[i].friends():
        print '   ',friend.screen_name
        ct=ct+1
    print '\n'
    print 'The Followers List for'
    print 'User ID: ', user[i].id
    print 'user name :',user[i].name
    print 'screen name :' , user[i].screen_name
    print''
    cts=0
    for followers in user[i].followers():
        print '   ',followers.screen_name
        cts=cts+1
    print '\n'    
    i+=1

