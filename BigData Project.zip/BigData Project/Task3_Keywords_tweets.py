from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import json
import tweepy

consumer_key="moA5lC8ePr2jaVNSjtVANaxdM"
consumer_secret="U9vGwuxK7ohStSUjksGlE3G7JbhslrEhtD9Jby1inpvxU6z62p"
access_token_key="923007546767572993-Tw3kbiIraEFUtCSmWXPR8vLQqFoiC2A"
access_token_secret="l3iYPVciQjLfvtzqTApWWeLRmxwJv0khqXme4XOhlXoHN"

class listener(StreamListener):
    def on_data(self, data):
            all_data = json.loads(data)
            tweet = all_data["text"]
            username = all_data["user"]["screen_name"]
            Task3_Streamingoutput = open('Task3_Streamingoutput.txt', 'a')
            Task3_Streamingoutput.write(tweet.encode('utf-8'))
            Task3_Streamingoutput.write('\n')        
            print username, 'POSTED', tweet
            return True    
    
auth = tweepy.OAuthHandler(consumer_key,consumer_secret)
auth.set_access_token(access_token_key,access_token_secret)
keywords = ["Indiana","Weather"]
twitterStream = Stream(auth, listener())
twitterStream.filter(track=keywords, languages=["en"])
Task3_Streamingoutput.close()