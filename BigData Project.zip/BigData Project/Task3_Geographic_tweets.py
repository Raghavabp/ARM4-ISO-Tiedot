import tweepy
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import json



consumer_key="moA5lC8ePr2jaVNSjtVANaxdM"
consumer_secret="U9vGwuxK7ohStSUjksGlE3G7JbhslrEhtD9Jby1inpvxU6z62p"
access_token_key="923007546767572993-Tw3kbiIraEFUtCSmWXPR8vLQqFoiC2A"
access_token_secret="l3iYPVciQjLfvtzqTApWWeLRmxwJv0khqXme4XOhlXoHN"

class StdOutListener(StreamListener):
    def __init__(self, api=None):
        super(StdOutListener, self).__init__()
        self.num_tweets = 0

    def on_data(self, data):
        self.num_tweets += 1
        if self.num_tweets < 50: 
            all_data = json.loads(data)
            tweet = all_data["text"]
            username = all_data["user"]["screen_name"]
            Task3_GeographicTweets = open('Task3_GeographicTweets.txt', 'a')
            Task3_GeographicTweets.write(tweet.encode('utf-8'))
            Task3_GeographicTweets.write('\n')            
            print username, 'POSTED', tweet
            return True
        else:
            return False

    def on_error(self, status):
        print status
        
l = StdOutListener()
auth = tweepy.OAuthHandler(consumer_key,consumer_secret)
auth.set_access_token(access_token_key,access_token_secret)
api=tweepy.API(auth)

stream = Stream(auth, l)
stream.filter(locations = [-86.33,41.63,-86.20,41.74] )

