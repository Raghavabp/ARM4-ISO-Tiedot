import tweepy

consumer_key="moA5lC8ePr2jaVNSjtVANaxdM"
consumer_secret="U9vGwuxK7ohStSUjksGlE3G7JbhslrEhtD9Jby1inpvxU6z62p"
access_token_key="923007546767572993-Tw3kbiIraEFUtCSmWXPR8vLQqFoiC2A"
access_token_secret="l3iYPVciQjLfvtzqTApWWeLRmxwJv0khqXme4XOhlXoHN"

auth = tweepy.OAuthHandler(consumer_key,consumer_secret)
auth.set_access_token(access_token_key,access_token_secret)

api=tweepy.API(auth)

user = [api.get_user(34373370,), api.get_user(26257166), api.get_user(12579252)]

i=0
while i<len(user):
    print "Information for ID: ", user[i].id ," is: "
    print ''
    print "Screen Name: ", user[i].screen_name 
    print "User Name: ", user[i].name
    print "Location:", user[i].location
    print "User Description:", user[i].description
    print "The Number of Followers:", user[i].followers_count
    print "Number of Friends:" , user[i].friends_count
    print "Number of Statuses: ", user[i].statuses_count
    print "User URL:", user[i].url
    print '\n'
    i+=1
